// Fetch blog posts and display them on the index.html page
if (window.location.pathname === "/index.html") {
    window.addEventListener('load', function() {
        fetch('http://localhost:8080/api/posts')
            .then(response => response.json())
            .then(posts => {
                const blogPostsContainer = document.getElementById("blog-posts");
                posts.forEach(post => {
                    const postElement = document.createElement("div");
                    postElement.classList.add("blog-post");
                    postElement.innerHTML = `
                        <h3>${post.title}</h3>
                        <p>${post.content.substring(0, 100)}...</p>
                        <a href="blog_detail.html?id=${post.id}">Read more</a>
                    `;
                    blogPostsContainer.appendChild(postElement);
                });
            });
    });
}

// Handle login form submission
if (window.location.pathname === "/login.html") {
    document.getElementById("loginForm").addEventListener("submit", function(event) {
        event.preventDefault();
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        fetch("http://localhost:8080/api/authenticate", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => response.json())
        .then(data => {
            localStorage.setItem("token", data.token);
            window.location.href = "index.html";
        })
        .catch(error => {
            alert("Login failed");
        });
    });
}

// Handle signup form submission
if (window.location.pathname === "/signup.html") {
    document.getElementById("signupForm").addEventListener("submit", function(event) {
        event.preventDefault();
        const username = document.getElementById("signupUsername").value;
        const password = document.getElementById("signupPassword").value;

        fetch("http://localhost:8080/api/users", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username, password })
        })
        .then(response => response.json())
        .then(data => {
            window.location.href = "login.html";
        })
        .catch(error => {
            alert("Signup failed");
        });
    });
}

// Handle blog creation form submission
if (window.location.pathname === "/create_blog.html") {
    document.getElementById("createBlogForm").addEventListener("submit", function(event) {
        event.preventDefault();
        const title = document.getElementById("title").value;
        const content = document.getElementById("content").value;

        const token = localStorage.getItem("token");
        fetch("http://localhost:8080/api/posts", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({ title, content })
        })
        .then(response => response.json())
        .then(data => {
            window.location.href = "index.html";
        })
        .catch(error => {
            alert("Failed to create blog post");
        });
    });
}

// Fetch and display blog post details
if (window.location.pathname === "/blog_detail.html") {
    const urlParams = new URLSearchParams(window.location.search);
    const postId = urlParams.get('id');

    fetch(`http://localhost:8080/api/posts/${postId}`)
        .then(response => response.json())
        .then(post => {
            const blogDetailContainer = document.getElementById("blog-detail");
            blogDetailContainer.innerHTML = `
                <h2>${post.title}</h2>
                <p>${post.content}</p>
            `;
        });
}
